package wonud.dev.picktrimcompress;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.io.File;
import java.net.URISyntaxException;

import wonud.dev.trimncompress.K4LVideoTrimmer;
import wonud.dev.trimncompress.SiliCompressor;
import wonud.dev.trimncompress.interfaces.OnK4LVideoListener;
import wonud.dev.trimncompress.interfaces.OnTrimVideoListener;

public class VideoTrimmerActvity extends AppCompatActivity implements OnTrimVideoListener, OnK4LVideoListener {


    private K4LVideoTrimmer mVideoTrimmer;
    private ProgressDialog mProgressDialog;
    private String videoPath = "";
    private String root = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trimmer);

        videoPath = getIntent().getExtras().getString("videopath");

        root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + "/duNOW Media");
        if (!myDir.exists()) {
            myDir.mkdirs();
        }


        //setting progressbar
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setMessage("Trimming in Progress");

        mVideoTrimmer = ((K4LVideoTrimmer) findViewById(R.id.timeLine));
        if (mVideoTrimmer != null) {
            mVideoTrimmer.setMaxDuration(90);
            mVideoTrimmer.setOnTrimVideoListener(this);
            mVideoTrimmer.setOnK4LVideoListener(this);
            mVideoTrimmer.setDestinationPath(root + "/PickTrimCompress");
            mVideoTrimmer.setVideoURI(Uri.fromFile(new File(videoPath)));
            mVideoTrimmer.setVideoInformationVisibility(true);
        }

    }

    // OnTrimVideoListener Methods
    @Override
    public void onTrimStarted() {

        mProgressDialog.show();

    }

    @Override
    public void getResult(final Uri uri) {

        mProgressDialog.cancel();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(VideoTrimmerActvity.this, "Video saved at: "  + uri.getPath(), Toast.LENGTH_SHORT).show();
            }
        });

        new VideoCompressAsyncTask().execute(uri.getPath(), root + "/duNOW Media");
//        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
//        intent.setDataAndType(uri, "video/mp4");
//        startActivity(intent);
//        finish();

        //Begin to compress the file


    }

    @Override
    public void cancelAction() {

        mProgressDialog.cancel();
        mVideoTrimmer.destroy();
        finish();

    }

    @Override
    public void onError(final String message) {

        mProgressDialog.cancel();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(VideoTrimmerActvity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }


    // OnK4LVideoListener methods
    @Override
    public void onVideoPrepared() {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(VideoTrimmerActvity.this, "onVideoPrepared", Toast.LENGTH_SHORT).show();
            }
        });

    }

    class VideoCompressAsyncTask extends AsyncTask<String, String, String>
    {

        @Override
        protected String doInBackground(String... paths) {
            String filePath = null;
            try {

                filePath = SiliCompressor.with(VideoTrimmerActvity.this).compressVideo(paths[0], paths[1]);

            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
            return filePath;
        }

        @Override
        protected void onPostExecute(final String compressedFilePath) {
            super.onPostExecute(compressedFilePath);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(VideoTrimmerActvity.this, "Compressed File Located at: " +  compressedFilePath, Toast.LENGTH_SHORT).show();
                }
            });
        }






    }


}
