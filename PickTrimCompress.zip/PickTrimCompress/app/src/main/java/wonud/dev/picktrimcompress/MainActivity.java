package wonud.dev.picktrimcompress;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.File;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button btnPickAMp4File;
    private static final int REQUEST_CODE_PICK_VIDEO = 747;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPickAMp4File = (Button) findViewById(R.id.button);
        btnPickAMp4File.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Check Permissions
                PermissionListener permissionlistener = new PermissionListener() {
                    @Override
                    public void onPermissionGranted() {

                        //Go Pick a Video

                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        //Pick only mp4 videos
                        intent.setType("video/mp4");
                        startActivityForResult(intent, REQUEST_CODE_PICK_VIDEO);


                    }

                    @Override
                    public void onPermissionDenied(List<String> deniedPermissions) {

                        Toast.makeText(MainActivity.this, "This feature needs your permission to work properly", Toast.LENGTH_SHORT).show();
                    }


                };

                TedPermission.with(MainActivity.this)
                        .setPermissionListener(permissionlistener)
                        .setDeniedMessage("This feature needs your permission to work properly")
                        .setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        .check();


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (requestCode == REQUEST_CODE_PICK_VIDEO) {
            Uri uri = data.getData();

            if (uri != null) {

                cursor = getContentResolver().query(uri, null, null, null, null, null);
            }

            try {

                if (cursor != null && cursor.moveToFirst()) {

                    String displayName = cursor.getString(
                            cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));

                    int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                    String size = null;
                    if (!cursor.isNull(sizeIndex)) {
                        size = cursor.getString(sizeIndex);
                    } else {
                        size = "Unknown";
                    }

                    String root = Environment.getExternalStorageDirectory().toString();
                    File myDir = new File(root + "/duNOW Media");
                    if (!myDir.exists()) {
                        myDir.mkdirs();
                    }

                    String tmpPath = RealPathUtil.getRealPath(this, uri);

                    //Go to Trimmer Actvity
                    Intent iTrim = new Intent(MainActivity.this, VideoTrimmerActvity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("videopath", tmpPath);
                    iTrim.putExtras(bundle);
                    startActivity(iTrim);


                }

            } finally {
                //Do nothing
            }

        }
    }
}
